const user = require('./user');
const home = require('./home');
const article = require('./article');

module.exports = {
    user,
    home,
    article,
};